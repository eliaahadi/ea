from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database_setup import Country, Base, MenuItem

engine = create_engine('sqlite:///countrymenu.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object. Any change made against the objects in the
# session won't be persisted into the database until you call
# session.commit(). If you're not happy about the changes, you can
# revert all of them back to the last commit by calling
# session.rollback()
session = DBSession()


# Menu for USA
country1 = Country(name="United States of America (USA)")

session.add(country1)
session.commit()


menuItem1 = MenuItem(name="NYC Statue of Liberty", description="ticket to see the statue",
                     price="$30", category="Sights", country=country1)

session.add(menuItem1)
session.commit()

menuItem2 = MenuItem(name="LA KoreanTown BBQ", description="Amazing Korean BBQ",
                     price="$20", category="Food", country=country1)

session.add(menuItem2)
session.commit()

menuItem3 = MenuItem(name="DC Cherry Blossom Festival", description="gorgeous pink spring flowers blooming",
                     price="$10", category="Events", country=country1)

session.add(menuItem3)
session.commit()



# Menu for Afghanistan
country2 = Country(name="Afghanistan")

session.add(country2)
session.commit()


menuItem1 = MenuItem(name="Buddhas of Bamiyan", description="With your choice of noodles vegetables and sauces",
                     price="$30", category="Sights", country=country2)

session.add(menuItem1)
session.commit()

menuItem2 = MenuItem(name="Steamed Mantu Dumplings", description="Filled with lamb/beef with veggie sauce on outside",
                     price="5", category="Food", country=country2)

session.add(menuItem2)
session.commit()

menuItem3 = MenuItem(name="National Museum of Afghanistan", description="collection of historical Afghan antiques",
                     price="10", category="Events", country=country2)

session.add(menuItem3)
session.commit()




# Menu for Japan
country3 = Country(name="Japan")

session.add(country3)
session.commit()


menuItem1 = MenuItem(name="Fushimi Inari-taisha Shrine ", description="amazing Shinto shrine in Kyoto",
                     price="$10", category="Sights", country=country3)

session.add(menuItem1)
session.commit()

menuItem2 = MenuItem(name="Ramen", description="famous noodle shop in Tokyo",
                     price="$8", category="Food", country=country3)

session.add(menuItem2)
session.commit()

menuItem3 = MenuItem(name="Setsubun Mantoro (Lantern Festival)", description="traditional lantern festival in Nara",
                     price="$5", category="Events", country=country3)

session.add(menuItem3)
session.commit()


print "added menu items for countries!"
