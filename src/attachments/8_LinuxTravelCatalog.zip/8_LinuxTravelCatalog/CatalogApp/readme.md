Elia's Udacity Project Travel Item Catalog
=====================

Demo project to view a list of countries and things to do there including sights, food, and events. Also a user can create a new country with things to do and create, edit, and delete items. 

Tested on Chrome, Safari & Firefox.

---

## Website/demo
If you'd like to see the final website without running the Python code, open this file:
https://github.com/elia314/udacity-fullstackweb/blob/master/4_2_Itemcatalog/itemcatalog/travelcat.py

---

## Features
- Clicking on a country shows you the sights, food, and events to see if there are you listed.
- Can also add/delete/edit a country with their sights, food, and events.
- Existing countries listed are Brazil, Japan, Italy, and China.
---

## Setup
If you'd like to make any edits/view the project, fork this repository on Github.


Clone this repo to a folder in your computer to edit it on as local files on your computer.
```
$ git clone https://github.com/elia314/udacity-fullstackweb/blob/master/4_2_Itemcatalog/
```

Go to the project directory.
```
$ cd 4_2_Itemcatalog
```
To view the catalog website, open the file below in the repo and run it from Python IDLE:
travelcat.py

A website will be created from that file output.

---

## Bug / Feature Request

If you find a bug (the trailers didn't load / or gave undesired results), kindly open an issue [here](https://github.com/elia314/ea/issues) by including what you did and the expected result.


---

## Built with


- Python - Free , Rich Gallery , Customizable and Cross-browser compatible.
- Bootstrap 3 - Extensive list of components and Bundled Javascript plugins.
- HTML/CSS - Foundational code to modify the web design

---

## Usage
Make sure you are in the project directory and that you have python 3 installed.

Build the project. This should automatically open a local HTML file in your default browser with a selected list of movies. Enjoy!

---

## Credits

-Thanks for lessons to build this project Udacity.

---

## License

-N/A
